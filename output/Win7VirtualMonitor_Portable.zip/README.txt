﻿Win7 Virtual Monitor - Portable Edition
========================================

Stream your Windows display to Android devices over WiFi.

Usage:
1. Run Win7App.exe as Administrator
2. Configure HTTP port (default: 8080) and optional HTTPS
3. Set a password for security
4. Click "Start Server"
5. On Android, open Chrome and navigate to:
   http://<your-pc-ip>:8080
6. Enter the password and enjoy!

Features:
- Real-time screen streaming (MJPEG)
- Touch input support
- Audio streaming (optional)
- PWA support (Add to Home Screen)
- Fullscreen mode

Requirements:
- Windows 7 or later
- .NET Framework 4.6.1
- Administrator privileges (for input injection)

Note: Make sure Windows Firewall allows the app on ports 8080/8081.
